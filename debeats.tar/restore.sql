--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE debeats;
--
-- Name: debeats; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE debeats WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE debeats OWNER TO postgres;

\connect debeats

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    cat_cd_id integer NOT NULL,
    cat_tx_nome character varying(50),
    cat_tx_descricao character varying(200)
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_cat_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoria_cat_cd_id_seq OWNER TO postgres;

--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_cat_cd_id_seq OWNED BY public.categoria.cat_cd_id;


--
-- Name: cidade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cidade (
    cid_cd_id integer NOT NULL,
    cid_tx_nome character varying(50),
    fk_est_cd_id integer
);


ALTER TABLE public.cidade OWNER TO postgres;

--
-- Name: cidade_cid_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cidade_cid_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cidade_cid_cd_id_seq OWNER TO postgres;

--
-- Name: cidade_cid_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cidade_cid_cd_id_seq OWNED BY public.cidade.cid_cd_id;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    cli_cd_id integer NOT NULL,
    cli_tx_nomeusu character varying(20),
    cli_dt_datanasc date,
    fk_user_cd_id integer,
    fk_end_cd_id integer
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: cliente_cli_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cliente_cli_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cliente_cli_cd_id_seq OWNER TO postgres;

--
-- Name: cliente_cli_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cliente_cli_cd_id_seq OWNED BY public.cliente.cli_cd_id;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    end_cd_id integer NOT NULL,
    end_tx_rua character varying(50),
    end_tx_bairro character varying(50),
    end_char_cep character varying(8),
    end_int_numero integer,
    fk_cid_cd_id integer
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_end_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.endereco_end_cd_id_seq OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_end_cd_id_seq OWNED BY public.endereco.end_cd_id;


--
-- Name: estado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado (
    est_cd_id integer NOT NULL,
    est_tx_estado character varying(50),
    est_tx_sigla character varying(50),
    est_tx_pais character varying(8)
);


ALTER TABLE public.estado OWNER TO postgres;

--
-- Name: estado_est_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_est_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estado_est_cd_id_seq OWNER TO postgres;

--
-- Name: estado_est_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_est_cd_id_seq OWNED BY public.estado.est_cd_id;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcionario (
    fun_cd_id integer NOT NULL,
    fk_user_cd_id integer
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.funcionario_fun_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.funcionario_fun_cd_id_seq OWNER TO postgres;

--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.funcionario_fun_cd_id_seq OWNED BY public.funcionario.fun_cd_id;


--
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido (
    ped_cd_id integer NOT NULL,
    ped_tx_forma_pg character varying(50),
    ped_tx_num_cartao character varying(16),
    fk_cli_cd_id integer,
    ped_dt_data_venda date
);


ALTER TABLE public.pedido OWNER TO postgres;

--
-- Name: pedido_produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_produto (
    pedpro_cd_id integer NOT NULL,
    fk_pro_cd_id integer,
    fk_ped_cd_id integer,
    pedpro_int_quantidade integer
);


ALTER TABLE public.pedido_produto OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    pro_cd_id integer NOT NULL,
    pro_tx_nomepro character varying(20),
    pro_tx_descricao character varying(256),
    pro_int_estoque integer,
    pro_dt_datafab date,
    pro_nm_valor real,
    fk_fun_cd_id integer,
    fk_cat_cd_id integer
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    user_cd_id integer NOT NULL,
    user_tx_nome character varying(50),
    user_tx_cpf character varying(11),
    user_tx_senha character varying(20),
    user_tx_email character varying(50)
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: nota_fiscal; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.nota_fiscal AS
 SELECT p.ped_tx_forma_pg,
    p.ped_dt_data_venda,
    pp.pedpro_int_quantidade,
    pr.pro_nm_valor,
    ((pp.pedpro_int_quantidade)::double precision * pr.pro_nm_valor) AS preco_total,
    pr.pro_tx_nomepro,
    u.user_tx_nome,
    u.user_tx_cpf
   FROM ((((public.usuario u
     JOIN public.cliente c ON ((u.user_cd_id = c.fk_user_cd_id)))
     JOIN public.pedido p ON ((c.cli_cd_id = p.fk_cli_cd_id)))
     JOIN public.pedido_produto pp ON ((p.ped_cd_id = pp.fk_ped_cd_id)))
     JOIN public.produto pr ON ((pp.fk_pro_cd_id = pr.pro_cd_id)));


ALTER TABLE public.nota_fiscal OWNER TO postgres;

--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_ped_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_ped_cd_id_seq OWNER TO postgres;

--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_ped_cd_id_seq OWNED BY public.pedido.ped_cd_id;


--
-- Name: pedido_produto_pedpro_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_produto_pedpro_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_produto_pedpro_cd_id_seq OWNER TO postgres;

--
-- Name: pedido_produto_pedpro_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_produto_pedpro_cd_id_seq OWNED BY public.pedido_produto.pedpro_cd_id;


--
-- Name: produto_pro_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_pro_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_pro_cd_id_seq OWNER TO postgres;

--
-- Name: produto_pro_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_pro_cd_id_seq OWNED BY public.produto.pro_cd_id;


--
-- Name: usuario_user_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_user_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_user_cd_id_seq OWNER TO postgres;

--
-- Name: usuario_user_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_user_cd_id_seq OWNED BY public.usuario.user_cd_id;


--
-- Name: categoria cat_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN cat_cd_id SET DEFAULT nextval('public.categoria_cat_cd_id_seq'::regclass);


--
-- Name: cidade cid_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidade ALTER COLUMN cid_cd_id SET DEFAULT nextval('public.cidade_cid_cd_id_seq'::regclass);


--
-- Name: cliente cli_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN cli_cd_id SET DEFAULT nextval('public.cliente_cli_cd_id_seq'::regclass);


--
-- Name: endereco end_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN end_cd_id SET DEFAULT nextval('public.endereco_end_cd_id_seq'::regclass);


--
-- Name: estado est_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado ALTER COLUMN est_cd_id SET DEFAULT nextval('public.estado_est_cd_id_seq'::regclass);


--
-- Name: funcionario fun_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN fun_cd_id SET DEFAULT nextval('public.funcionario_fun_cd_id_seq'::regclass);


--
-- Name: pedido ped_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido ALTER COLUMN ped_cd_id SET DEFAULT nextval('public.pedido_ped_cd_id_seq'::regclass);


--
-- Name: pedido_produto pedpro_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto ALTER COLUMN pedpro_cd_id SET DEFAULT nextval('public.pedido_produto_pedpro_cd_id_seq'::regclass);


--
-- Name: produto pro_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN pro_cd_id SET DEFAULT nextval('public.produto_pro_cd_id_seq'::regclass);


--
-- Name: usuario user_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN user_cd_id SET DEFAULT nextval('public.usuario_user_cd_id_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3415.dat

--
-- Data for Name: cidade; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3423.dat

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3427.dat

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3425.dat

--
-- Data for Name: estado; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3421.dat

--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3419.dat

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3429.dat

--
-- Data for Name: pedido_produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3433.dat

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3431.dat

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3417.dat

--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_cat_cd_id_seq', 9, true);


--
-- Name: cidade_cid_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cidade_cid_cd_id_seq', 1, false);


--
-- Name: cliente_cli_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cliente_cli_cd_id_seq', 6, true);


--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_end_cd_id_seq', 5, true);


--
-- Name: estado_est_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estado_est_cd_id_seq', 1, false);


--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.funcionario_fun_cd_id_seq', 5, true);


--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_ped_cd_id_seq', 10, true);


--
-- Name: pedido_produto_pedpro_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_produto_pedpro_cd_id_seq', 20, true);


--
-- Name: produto_pro_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_pro_cd_id_seq', 23, true);


--
-- Name: usuario_user_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_user_cd_id_seq', 5, true);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (cat_cd_id);


--
-- Name: cidade cidade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidade
    ADD CONSTRAINT cidade_pkey PRIMARY KEY (cid_cd_id);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (cli_cd_id);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_cd_id);


--
-- Name: estado estado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado
    ADD CONSTRAINT estado_pkey PRIMARY KEY (est_cd_id);


--
-- Name: funcionario funcionario_fk_user_cd_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_fk_user_cd_id_key UNIQUE (fk_user_cd_id);


--
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (fun_cd_id);


--
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (ped_cd_id);


--
-- Name: pedido_produto pedido_produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto
    ADD CONSTRAINT pedido_produto_pkey PRIMARY KEY (pedpro_cd_id);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (pro_cd_id);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (user_cd_id);


--
-- Name: usuario usuario_user_tx_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_user_tx_cpf_key UNIQUE (user_tx_cpf);


--
-- Name: nomecidade; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX nomecidade ON public.cidade USING btree (cid_tx_nome);


--
-- Name: nomeest; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX nomeest ON public.estado USING btree (est_tx_estado);


--
-- Name: nomeproduto; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX nomeproduto ON public.produto USING btree (pro_tx_nomepro);


--
-- Name: nomerua; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX nomerua ON public.endereco USING btree (end_tx_rua);


--
-- Name: nomeuser; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX nomeuser ON public.usuario USING btree (user_tx_nome);


--
-- Name: cidade cidade_fk_est_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidade
    ADD CONSTRAINT cidade_fk_est_cd_id_fkey FOREIGN KEY (fk_est_cd_id) REFERENCES public.estado(est_cd_id);


--
-- Name: cliente cliente_fk_end_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_fk_end_cd_id_fkey FOREIGN KEY (fk_end_cd_id) REFERENCES public.endereco(end_cd_id);


--
-- Name: cliente cliente_fk_user_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_fk_user_cd_id_fkey FOREIGN KEY (fk_user_cd_id) REFERENCES public.usuario(user_cd_id);


--
-- Name: endereco endereco_fk_cid_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_fk_cid_cd_id_fkey FOREIGN KEY (fk_cid_cd_id) REFERENCES public.cidade(cid_cd_id);


--
-- Name: funcionario funcionario_fk_user_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_fk_user_cd_id_fkey FOREIGN KEY (fk_user_cd_id) REFERENCES public.usuario(user_cd_id);


--
-- Name: pedido pedido_fk_cli_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_fk_cli_cd_id_fkey FOREIGN KEY (fk_cli_cd_id) REFERENCES public.cliente(cli_cd_id);


--
-- Name: pedido_produto pedido_produto_fk_ped_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto
    ADD CONSTRAINT pedido_produto_fk_ped_cd_id_fkey FOREIGN KEY (fk_ped_cd_id) REFERENCES public.pedido(ped_cd_id);


--
-- Name: pedido_produto pedido_produto_fk_pro_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto
    ADD CONSTRAINT pedido_produto_fk_pro_cd_id_fkey FOREIGN KEY (fk_pro_cd_id) REFERENCES public.produto(pro_cd_id);


--
-- Name: produto produto_fk_cat_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_fk_cat_cd_id_fkey FOREIGN KEY (fk_cat_cd_id) REFERENCES public.categoria(cat_cd_id);


--
-- Name: produto produto_fk_fun_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_fk_fun_cd_id_fkey FOREIGN KEY (fk_fun_cd_id) REFERENCES public.funcionario(fun_cd_id);


--
-- PostgreSQL database dump complete
--

